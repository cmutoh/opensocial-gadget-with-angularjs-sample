# opensocial-gadget-with-angularjs-sample

This is a opensocial gadget sample working with angular.js and works on infoScoop OpenSource V4.0.

## How to make this work
Donload infoscoop-4.0.0.0-quickstart from here and install it.
Go to administrator page > Gadgets.
Upload my gadget, opensocial-angular-sample.zip.
Go to administrator page > Menu and register the gadget on menu.
Now you can drop the gadget from menu on portal.